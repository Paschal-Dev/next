// import { Box, Container, useMediaQuery } from "@mui/material";

// import { theme } from "../../../assets/themes/theme";
// import voucherMenu from "../../../assets/images/voucher/voucher-sub-menu.png";

// export default function VoucherSubMenu() {
//     const isMobile = useMediaQuery(theme.breakpoints.down("md"));
//     return (
//         <Box bgcolor={"#e8e8e8"} pb={13}>
//             <Container>
                
//             </Container>
//         </Box>
//     );
// }
